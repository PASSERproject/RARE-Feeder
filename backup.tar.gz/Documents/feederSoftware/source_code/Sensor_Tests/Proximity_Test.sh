#!/bin/bash

# John Filipowicz
# Radford University

# Purpose: Test the proximity sensor through outputting sensor data

python ~/Documents/feederSoftware/sensor_libraries/Proximity_Python_Library/Adafruit_Python_VCNL40xx/examples/simpletest.py
